from io import BytesIO
from PIL import Image
import uuid

from django.core.files import File
from django.db import models

class Category(models.Model):
    name = models.CharField("Название", max_length=255)
    icon = models.FileField("Иконка", upload_to='icon/')

    def get_icon(self):
        if self.icon:
            return 'https://test-kidsee.ru' + self.icon.url
        return ''

    class Meta:
        ordering = ('name',)
    
    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Жанр"
        verbose_name_plural = "Жанры"

class Studios(models.Model):
    name = models.CharField("Название", max_length=255)
    icon = models.FileField("Иконка", upload_to='icon/')

    def get_icon(self):
        if self.icon:
            return 'https://test-kidsee.ru' + self.icon.url
        return ''

    class Meta:
        ordering = ('name',)
    
    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Студия"
        verbose_name_plural = "Студии"

class Video(models.Model):
    unique_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    category_id = models.ForeignKey(Category, related_name='categorys', verbose_name="Жанр видео", on_delete=models.CASCADE, blank=True, null=True)
    studios_id = models.ForeignKey(Studios, related_name='studioys', verbose_name="Студия видео", on_delete=models.CASCADE, blank=True, null=True)
    name = models.CharField("Название видео", max_length=255, blank=True)
    disk = models.TextField("Описание видео", max_length=255, blank=True)
    preview = models.FileField("Превью видео", upload_to='preview/')
    video = models.FileField("Файл видео", upload_to='videos/files/')
    date_added = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ('name',)

    def get_video(self):
        if self.video:
            return 'https://test-kidsee.ru' + self.video.url
        return ''

    def get_preview(self):
        if self.video:
            return 'https://test-kidsee.ru' + self.preview.url
        return ''

    def __str__(self):
        return self.name

    class Meta:
        ordering = ('-date_added',)
        verbose_name = "Видео"
        verbose_name_plural = "Видеотека"

class UserProfile(models.Model):
    name = models.CharField("Имя пользователя", max_length=255, blank=True)
    surname = models.CharField("Фамилия пользователя", max_length=255, blank=True)
    email = models.CharField("E-mail пользователя", max_length=255)
    city = models.CharField("Город пользователя", max_length=255, blank=True)
    adress = models.CharField("Улица пользователя", max_length=255, blank=True)
    token = models.CharField('Токен', max_length=255, blank=True)
    date_added = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ('-date_added',)
        verbose_name = "Профиль пользователя"
        verbose_name_plural = "Профили пользователей"

    def __str__(self):
        return self.email
