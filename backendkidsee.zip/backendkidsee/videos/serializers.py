from rest_framework import serializers

from .models import *

class VideoSerializer(serializers.ModelSerializer):

    class Meta:
        model = Video
        fields = (
            "unique_id",
            "category_id",
            "studios_id",
            "name",
            "disk",
            "get_preview",
            "get_video",
            "date_added",
        )

class CategorySerializer(serializers.ModelSerializer):
    categorys = VideoSerializer(many=True)

    class Meta:
        model = Category
        fields = (
            "id",
            "name",
            "get_icon",
            "categorys",
        )

class StudiosSerializer(serializers.ModelSerializer):
    studioys = VideoSerializer(many=True)

    class Meta:
        model = Studios
        fields = (
            "id",
            "name",
            "get_icon",
            "studioys",
        )

class UserProfileSerializer(serializers.ModelSerializer):

    class Meta:
        model = UserProfile
        fields = (
            "id",
            "name",
            "surname",
            "email",
            "city",
            "adress",
            "sub",
            "token"
        )