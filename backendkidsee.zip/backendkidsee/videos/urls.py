from django.urls import path, include

from videos import views

urlpatterns = [
    # Профиль
    path('myProfiles/', views.UserProfiles.as_view()),
    path('me/<int:pk>/', views.MyProfile.as_view()),

    # Видео
    path('videos_list/', views.VideoList.as_view()),
    path('video_detail/<str:uuid>/', views.VideoDetail.as_view()), 

    # Поиск
    path('video/search/', views.search),

    # Студия
    path('studio_list/', views.StudiosAll.as_view()),
    path('studio/<int:pk>/', views.StudioDetail.as_view()), 

    # Категория
    path('category_list/', views.CategoryAll.as_view()),
    path('category/<int:pk>/', views.CategoryDetail.as_view()), 

    # Загрузка видео в kidsee
    path('upload_file/<str:filename>', views.storeAndProcessFile.as_view()),
    path('upload_s3/', views.s3_upload.as_view()),
]