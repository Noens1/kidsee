from django.contrib import admin

from .models import *

admin.site.register(Category)
admin.site.register(Studios)
admin.site.register(Video)
admin.site.register(UserProfile)


admin.site.site_header = 'Kidse'
admin.site.site_title = 'Страница'