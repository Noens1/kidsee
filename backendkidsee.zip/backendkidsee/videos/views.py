from django.db.models import Q
from django.http import Http404, HttpResponseBadRequest, HttpResponse

from django.conf import settings
from django.template.loader import render_to_string
from django.template import Context
from django.core.mail import send_mail, EmailMultiAlternatives
from django.core.exceptions import MultipleObjectsReturned
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework import viewsets, generics
from rest_framework.pagination import PageNumberPagination
from django.utils import timezone

from rest_framework import status

from rest_framework.parsers import FileUploadParser

from .models import *
from .service import PaginationList
from .serializers import *

from yookassa import Configuration, Payment
import uuid
from django.views.decorators.csrf import csrf_exempt, csrf_protect

from django.core.files.storage import default_storage

import os
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile, File

import base64
import psycopg2
import boto3
import time

class VideoList(generics.ListAPIView):
    paginate_class = PaginationList
    queryset = Video.objects.all()
    serializer_class = VideoSerializer

class CategoryAll(generics.ListAPIView):
    paginate_class = PaginationList
    queryset = Category.objects.all()
    serializer_class = CategorySerializer

class StudiosAll(generics.ListAPIView):
    paginate_class = PaginationList
    queryset = Studios.objects.all()
    serializer_class = StudiosSerializer

class VideoDetail(APIView):
    def get_object(self, uuid):
        try:
            return Video.objects.get(unique_id=uuid)
        except Video.DoesNotExist:
            raise Http404
    
    def get(self, request, uuid, format=None):
        item = self.get_object(uuid)
        serializer = VideoSerializer(item)
        return Response(serializer.data)

class StudioDetail(APIView):
    def get_object(self, pk):
        try:
            return Studios.objects.get(id=pk)
        except Studios.DoesNotExist:
            raise Http404
    
    def get(self, request, pk, format=None):
        category = self.get_object(pk)
        serializer = StudiosSerializer(category)
        return Response(serializer.data)

class CategoryDetail(APIView):
    def get_object(self, pk):
        try:
            return Category.objects.get(id=pk)
        except Category.DoesNotExist:
            raise Http404
    
    def get(self, request, pk, format=None):
        category = self.get_object(pk)
        serializer = CategorySerializer(category)
        return Response(serializer.data)

@api_view(['POST'])
def search(request):
    query = request.data.get('query', '')

    if query:
        items = Video.objects.filter(name__icontains=query)
        serializer = VideoSerializer(items, many=True)
        return Response(serializer.data)
    else:
        return Response({"items": []})

class UserProfiles(APIView):
    def get(self, request, format=None):
        user_profiles = UserProfile.objects.all()
        serializer = UserProfileSerializer(user_profiles, many=True)
        return Response(serializer.data)

    def post(self, request, format=None):
        serializer = UserProfileSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class MyProfile(APIView):
    def get_object(self, pk):
        try:
            return UserProfile.objects.get(id=pk)
        except UserProfile.DoesNotExist:
            raise Http404
    
    def get(self, request, pk, format=None):
        myaccount = self.get_object(pk)
        serializer = UserProfileSerializer(myaccount)
        return Response(serializer.data)

    def put(self, request, pk, format=None):
        myaccount = self.get_object(pk)
        serializer = UserProfileSerializer(myaccount, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class storeAndProcessFile(APIView):
    parser_classes = [FileUploadParser]

    def put(self, request, filename, format=None):
        data = request.data['file']
        default_storage.save('videos_files/' + str(data), File(data))
        return Response(status=204)


class s3_upload(APIView):
    def post(self, request, format=None):
        data = request.data
        keyname = data['key']
        filename = data['file']
        epizod = data['epizod']
        uid = data['uuid']

        s3 = boto3.client(
            aws_access_key_id='20b80404-8ede-21c6-0001-100000000130',
            aws_secret_access_key='mG1kR5t8ks2cDlw3',
            service_name='s3',
            endpoint_url='https://s3.sheksy.com'
        )

        s3.put_object(Bucket='prod',Key=f'{keyname}/{epizod}/{uid}/')

        time.sleep(5)

        with open('videos_files/' + filename, "rb") as f:
            s3.upload_fileobj(f, Bucket='prod', Key=f'{keyname}/{epizod}/{uid}/{filename}')

        return Response(data)
